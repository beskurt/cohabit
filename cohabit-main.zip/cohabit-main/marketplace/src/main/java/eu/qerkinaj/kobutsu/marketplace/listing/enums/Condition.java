package eu.qerkinaj.kobutsu.marketplace.listing.enums;

public enum Condition {
    NEW,
    LIKE_NEW,
    USED_GOOD,
    USED_FAIR,
    USED,
    POOR
}
