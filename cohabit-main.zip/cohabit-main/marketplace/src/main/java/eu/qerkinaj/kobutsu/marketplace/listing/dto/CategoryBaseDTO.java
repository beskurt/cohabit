package eu.qerkinaj.kobutsu.marketplace.listing.dto;


public class CategoryBaseDTO {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}