package eu.qerkinaj.kobutsu.common;

public class Role {
    public static final String ADMIN = "ADMIN";
    public static final String USER = "USER";
}
